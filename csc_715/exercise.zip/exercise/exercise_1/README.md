To write a Python Program that will Accept
a comma separated sequence of words as input
and print words in a comma-separated sequence 
after sorting them alphabetically. For example
is the following is input to the program
"hello, from, the, other, side"
Then the output should be 
"From,  hello, other, side, then"

